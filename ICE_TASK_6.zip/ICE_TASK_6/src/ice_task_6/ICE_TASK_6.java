/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice_task_6;

import java.util.*;

public class ICE_TASK_6 {

    public static void main(String[] args) {
        Scanner ss = new Scanner(System.in);
        int i = 1;
        int amount;
        int total;
        total = 0;
        System.out.println("Enter the employee name :");
        String name = ss.nextLine();
        System.out.println("Enter sale 1 amount: ");
        amount = ss.nextInt();
        if (amount > 0) {
            ++i;
            System.out.println(amount);
            System.out.println("Enter sale " + i + " amount");
            amount = ss.nextInt();
            total = total + amount;
        }

        int average = total / i;
        System.out.println("EMPLOYEE SALE REPORT ");
        System.out.println("------------------------");
        System.out.println("Employee : " + name);
        System.out.println("");
        System.out.println("------------------------");
        System.out.println("Total Sold : " + total);
        System.out.println("------------------------");
        System.out.println("Sales count : " + i);
        System.out.println("AVerage sales : " + average);

    }

}
